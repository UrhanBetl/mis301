<?php 

$ocak_mantar1 = 	"0";
$ocak_mantar2 =		"0";
$ocak_gubre1  = 	"0";
$ocak_gubre2  = 	"0";
$ocak_bocek1  = 	"0";
$ocak_bocek2  = 	"0";

$subat_mantar1 =	"0";
$subat_mantar2 =	"0";
$subat_gubre1  =	"0";
$subat_gubre2  =	"0";
$subat_bocek1  =	"0";
$subat_bocek2  =	"0";

$mart_mantar1 = 	"0";
$mart_mantar2 = 	"0";
$mart_gubre1  = 	"0";
$mart_gubre2  = 	"0";
$mart_bocek1  =  	"0";
$mart_bocek2  =  	"0";

$nisan_mantar1 = 	"0";
$nisan_mantar2 = 	"0";
$nisan_gubre1  = 	"0";
$nisan_gubre2  = 	"0";
$nisan_bocek1  =  	"0";
$nisan_bocek2  =  	"0";

$mayis_mantar1 = "0";
$mayis_mantar2 = "0";
$mayis_gubre1  = "0";
$mayis_gubre2  = "0";
$mayis_bocek1  =  "0";
$mayis_bocek2  =  "0";

$haziran_mantar1 = "0";
$haziran_mantar2 = "0";
$haziran_gubre1  = "0";
$haziran_gubre2  = "0";
$haziran_bocek1  =  "0";
$haziran_bocek2  =  "0";

$temmuz_mantar1 = "0";
$temmuz_mantar2 = "0";
$temmuz_gubre1  = "0";
$temmuz_gubre2  = "0";
$temmuz_bocek1  =  "0";
$temmuz_bocek2  =  "0";

$agustos_mantar1 = "0";
$agustos_mantar2 = "0";
$agustos_gubre1  = "0";
$agustos_gubre2  = "0";
$agustos_bocek1  =  "0";
$agustos_bocek2  =  "0";

$eylul_mantar1 = "0";
$eylul_mantar2 = "0";
$eylul_gubre1  = "0";
$eylul_gubre2  = "0";
$eylul_bocek1  =  "0";
$eylul_bocek2  =  "0";

$ekim_mantar1 = "0";
$ekim_mantar2 = "0";
$ekim_gubre1  = "0";
$ekim_gubre2  = "0";
$ekim_bocek1  =  "0";
$ekim_bocek2  =  "0";

$kasim_mantar1 = "0";
$kasim_mantar2 = "0";
$kasim_gubre1  = "0";
$kasim_gubre2  = "0";
$kasim_bocek1  =  "0";
$kasim_bocek2  =  "0";

$aralik_mantar1 = "0";
$aralik_mantar2 = "0";
$aralik_gubre1  = "0";
$aralik_gubre2  = "0";
$aralik_bocek1  =  "0";
$aralik_bocek2  =  "0";
          

 ?>