<ul class="nav">
          <li class="nav-item">
            <a class="nav-link" href="index.php">
              <i class="icon ion-ios-home-outline"></i>
              <span>Ana Sayfa</span>
            </a>
          </li>
          <li class="nav-item with-sub">
            <a class="nav-link" href="#" data-toggle="dropdown">
              <i class="icon ion-ios-gear-outline"></i>
              <span>İşlemler</span>
            </a>
            <div class="sub-item">
              <ul>
                <li class="sub-with-sub">
                  <a href="#">İlaç</a>
                  <ul>
                    <li><a href="yeniilac.php">Stok Ekle / Çıkar</a></li>
                    <li><a href="ilaclistesi.php">İlaç Listesi</a></li>
                  </ul>
                </li>
                <li class="sub-with-sub">
                  <a href="#">Bitki</a>
                  <ul>
                    <li><a href="yenibitki.php">Yeni Bitki</a></li>
                    <li><a href="bitkilistesi.php">Bitki Listesi</a></li>
                  </ul>
                </li>
              </ul>
            </div><!-- dropdown-menu -->
          </li>
          <li class="nav-item with-sub">
            <a class="nav-link" href="#">
              <i class="icon ion-ios-book-outline"></i>
              <span>Raporlama</span>
            </a>
            <div class="sub-item">
              <ul>
                <li><a href="ilacmaliyet.php">İlaçlama Maliyetleri</a></li>
              </ul>
            </div><!-- dropdown-menu -->
          </li>
          <li class="nav-item with-sub">
            <a class="nav-link" href="#">
              <i class="icon ion-ios-analytics-outline"></i>
              <span>Ayarlar</span>
            </a>
            <div class="sub-item">
              <ul>
              
                  <li><a href="bildirimler.php">Bildirim Ayarları</a></li>

              </ul>
            </div>
          </li>
          
          
          
          
          
        </ul>